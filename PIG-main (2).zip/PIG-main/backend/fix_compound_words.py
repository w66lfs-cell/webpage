#!/usr/bin/env python3
"""
Fix Compound Words Script
Fixes entries where compound words were incorrectly split.
Example: "bean" with def "Flicker n. Lesbian" -> "bean flicker" with def "Lesbian"
"""

import re
from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()

# MongoDB connection
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
client = MongoClient(MONGO_URL)
db = client.word_of_day_db
words_collection = db.words

# Type markers pattern
TYPE_MARKERS_PATTERN = r'^(n\.|v\.|adj\.|euph\.|abbr\.|interj\.|rhym\. slang|sim\.|attr\.)'

def fix_compound_words():
    """Fix compound words that were incorrectly split"""
    print("Fixing compound words...")
    
    all_words = list(words_collection.find())
    print(f"Found {len(all_words)} words in database")
    
    fixed_count = 0
    to_delete = []
    
    for word_doc in all_words:
        definition = word_doc.get('definition', '')
        word = word_doc.get('word', '')
        
        # Pattern: Definition starts with Capitalized word followed by type marker
        # e.g., "Flicker n. Lesbian" or "Wound euph. Vagina"
        match = re.match(r'^([A-Z][a-z\'-]+)\s+(n\.|v\.|adj\.|euph\.|abbr\.|interj\.|rhym\.|sim\.|attr\.)\s*(.*)$', definition)
        
        if match:
            missing_word_part = match.group(1)  # e.g., "Flicker"
            type_marker = match.group(2)  # e.g., "n."
            actual_definition = match.group(3).strip()  # e.g., "Lesbian"
            
            # Build the compound word
            compound_word = f"{word} {missing_word_part.lower()}"
            
            # Check if the compound word already exists
            existing = words_collection.find_one({
                "word": {"$regex": f"^{re.escape(compound_word)}$", "$options": "i"}
            })
            
            if existing:
                # Compound word exists - mark this one for deletion
                to_delete.append(word_doc['_id'])
                if fixed_count < 20:
                    print(f"Will delete duplicate partial: '{word}' (compound '{compound_word}' exists)")
            else:
                # Update this entry to be the compound word
                words_collection.update_one(
                    {"_id": word_doc["_id"]},
                    {"$set": {
                        "word": compound_word.title() if word[0].isupper() else compound_word,
                        "definition": actual_definition if actual_definition else f"{type_marker} {definition}"
                    }}
                )
                fixed_count += 1
                if fixed_count <= 20:
                    print(f"Fixed: '{word}' -> '{compound_word}'")
                    print(f"  New def: {actual_definition[:60]}...")
    
    # Delete the duplicates
    for doc_id in to_delete:
        words_collection.delete_one({"_id": doc_id})
    
    print(f"\nFixed {fixed_count} compound words")
    print(f"Deleted {len(to_delete)} duplicate partial entries")
    return fixed_count, len(to_delete)

def clean_remaining_markers():
    """Clean any remaining type markers from definitions"""
    print("\nCleaning remaining type markers...")
    
    all_words = list(words_collection.find())
    fixed_count = 0
    
    for word_doc in all_words:
        definition = word_doc.get('definition', '')
        original = definition
        
        # Clean type markers at the start
        cleaned = re.sub(r'^(n\.|v\.|adj\.|euph\.|abbr\.|interj\.|rhym\.\s*slang|sim\.|attr\.)\s*', '', definition, flags=re.IGNORECASE)
        
        # Also clean regional prefixes + type markers
        cleaned = re.sub(r'^(US|Aus|UK|Eire|Welsh|Scotch|Scottish|Irish|Mexican|Gaelic|NZ|S\.\s*Africa)\s+(n\.|v\.|adj\.|euph\.)\s*', '', cleaned, flags=re.IGNORECASE)
        
        if cleaned != original:
            # Capitalize first letter if lowercase
            if cleaned and cleaned[0].islower():
                cleaned = cleaned[0].upper() + cleaned[1:]
            
            words_collection.update_one(
                {"_id": word_doc["_id"]},
                {"$set": {"definition": cleaned}}
            )
            fixed_count += 1
    
    print(f"Cleaned {fixed_count} definitions")
    return fixed_count

def remove_empty_or_invalid():
    """Remove entries with empty or very short definitions"""
    print("\nRemoving invalid entries...")
    
    result = words_collection.delete_many({
        "$or": [
            {"definition": ""},
            {"definition": {"$exists": False}},
            {"word": ""},
            {"word": {"$exists": False}}
        ]
    })
    
    print(f"Removed {result.deleted_count} invalid entries")
    return result.deleted_count

if __name__ == "__main__":
    print("="*60)
    print("Compound Words Fix Script")
    print("="*60)
    
    fixed, deleted = fix_compound_words()
    cleaned = clean_remaining_markers()
    removed = remove_empty_or_invalid()
    
    # Final count
    final_count = words_collection.count_documents({})
    
    print("\n" + "="*60)
    print("Summary:")
    print(f"  Compound words fixed: {fixed}")
    print(f"  Duplicates deleted: {deleted}")
    print(f"  Definitions cleaned: {cleaned}")
    print(f"  Invalid entries removed: {removed}")
    print(f"  Final word count: {final_count}")
    print("="*60)
