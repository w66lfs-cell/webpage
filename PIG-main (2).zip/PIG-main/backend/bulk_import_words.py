#!/usr/bin/env python3
"""
Bulk Word Import Script for Word of the Day App
Imports custom dictionary words from a text file into the database
"""

import requests
import json
import re
import sys
import time

API_URL = "http://localhost:8001/api/words"

def parse_dictionary_text(text):
    """
    Parse dictionary entries in the format:
    word n./v./adj. Definition text.
    
    Returns list of {word, definition} dicts
    """
    words = []
    
    # Split by lines and process
    lines = text.strip().split('\n')
    current_word = None
    current_def = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Check if line starts with a word (no leading spaces and has definition after)
        # Pattern: word followed by optional part of speech, then definition
        match = re.match(r'^([A-Za-z][A-Za-z\s\'-]+?)\s+(n\.|v\.|adj\.|euph\.|abbr\.|interj\.|rhym\.|sim\.|attr\.|archaic|US|Aus|Eire|Welsh|Scotch|Mexican|Gaelic|Thai|S\. Africa|NZ|UK)?\s*(.*)', line)
        
        if match:
            # Save previous word if exists
            if current_word:
                words.append({
                    "word": current_word,
                    "definition": ' '.join(current_def).strip()
                })
            
            # Start new word
            current_word = match.group(1).strip()
            pos = match.group(2) or ''
            definition = match.group(3).strip()
            
            # Clean up word (remove extra spaces)
            current_word = ' '.join(current_word.split())
            
            # Start definition
            current_def = [definition] if definition else []
        else:
            # Continuation of previous definition
            if current_word and line:
                current_def.append(line)
    
    # Add last word
    if current_word and current_def:
        words.append({
            "word": current_word,
            "definition": ' '.join(current_def).strip()
        })
    
    return words

def import_words(words, batch_size=10):
    """Import words to the API"""
    print(f"📚 Starting import of {len(words)} words...\n")
    
    success_count = 0
    failed_count = 0
    failed_words = []
    
    for i, word_data in enumerate(words, 1):
        try:
            response = requests.post(
                API_URL,
                json={
                    "word": word_data["word"],
                    "definition": word_data["definition"],
                    "is_favorite": False
                },
                timeout=10
            )
            
            if response.status_code == 200:
                success_count += 1
                print(f"✓ [{i}/{len(words)}] Added: {word_data['word']}")
            else:
                failed_count += 1
                failed_words.append(word_data['word'])
                print(f"✗ [{i}/{len(words)}] Failed: {word_data['word']} (Status: {response.status_code})")
                
        except Exception as e:
            failed_count += 1
            failed_words.append(word_data['word'])
            print(f"✗ [{i}/{len(words)}] Error: {word_data['word']} - {str(e)}")
        
        # Small delay to avoid overwhelming the API
        if i % batch_size == 0:
            time.sleep(0.5)
    
    # Summary
    print("\n" + "="*60)
    print(f"📊 Import Summary:")
    print(f"   ✅ Successfully imported: {success_count}")
    print(f"   ❌ Failed: {failed_count}")
    print(f"   📈 Success rate: {(success_count/len(words)*100):.1f}%")
    print("="*60)
    
    if failed_words:
        print(f"\n⚠️  Failed words: {', '.join(failed_words[:10])}")
        if len(failed_words) > 10:
            print(f"   ... and {len(failed_words)-10} more")

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 bulk_import_words.py <dictionary_file.txt>")
        print("\nOr provide dictionary text directly when prompted.")
        print("\nExpected format:")
        print("  word n. Definition text.")
        print("  another word v. Another definition.")
        sys.exit(1)
    
    # Read from file
    filename = sys.argv[1]
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            dictionary_text = f.read()
    except FileNotFoundError:
        print(f"❌ Error: File '{filename}' not found")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        sys.exit(1)
    
    # Parse the dictionary
    print("📖 Parsing dictionary entries...")
    words = parse_dictionary_text(dictionary_text)
    
    if not words:
        print("❌ No words found in the file. Please check the format.")
        sys.exit(1)
    
    print(f"✅ Parsed {len(words)} words\n")
    
    # Show preview
    print("Preview of first 3 words:")
    for word in words[:3]:
        print(f"  • {word['word']}: {word['definition'][:80]}...")
    print()
    
    # Confirm
    response = input(f"Import {len(words)} words? (yes/no): ").lower()
    if response not in ['yes', 'y']:
        print("❌ Import cancelled")
        sys.exit(0)
    
    # Import
    import_words(words)

if __name__ == "__main__":
    main()
