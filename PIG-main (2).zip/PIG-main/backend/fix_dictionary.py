#!/usr/bin/env python3
"""
Fix Dictionary Script
Cleans up word entries by removing type markers from definitions
and fixing incorrectly parsed words.
"""

import re
from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()

# MongoDB connection
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
client = MongoClient(MONGO_URL)
db = client.word_of_day_db
words_collection = db.words

# Type markers to strip from beginning of definitions
TYPE_MARKERS = [
    r'^n\.\s*',           # noun
    r'^v\.\s*',           # verb  
    r'^adj\.\s*',         # adjective
    r'^adv\.\s*',         # adverb
    r'^euph\.\s*',        # euphemism
    r'^abbr\.\s*',        # abbreviation
    r'^interj\.\s*',      # interjection
    r'^rhym\.\s*slang\s*', # rhyming slang
    r'^sim\.\s*',         # simile
    r'^attr\.\s*',        # attributed
    r'^archaic\s*',       # archaic
    r'^posh\s+euph\.\s*', # posh euphemism
    r'^polite\s+euph\.\s*', # polite euphemism
    r'^disaffectionate\s+euph\.\s*', # disaffectionate euphemism
    r'^affectionate\s+euph\.\s*', # affectionate euphemism
    r'^boastful\s+euph\.\s*', # boastful euphemism
    r'^jovial\s+euph\.\s*', # jovial euphemism
    r'^chauvinistic\s+euph\.\s*', # chauvinistic euphemism
    r'^US\s+euph\.\s*',   # US euphemism
    r'^Aus\s+euph\.\s*',  # Australian euphemism
    r'^UK\s+euph\.\s*',   # UK euphemism
    r'^US\s+n\.\s*',      # US noun
    r'^Aus\s+n\.\s*',     # Australian noun
    r'^Aus\.\s+n\.\s*',   # Australian noun (alt)
    r'^Aus\s+v\.\s*',     # Australian verb
    r'^UK\s+n\.\s*',      # UK noun
    r'^Eire\s+n\.\s*',    # Irish noun
    r'^Welsh\s+n\.\s*',   # Welsh noun
    r'^Scotch\s+n\.\s*',  # Scottish noun
    r'^Scotch\s+v\.\s*',  # Scottish verb
    r'^Mexican\s+n\.\s*', # Mexican noun
    r'^Gaelic\s+n\.\s*',  # Gaelic noun
    r'^Gaelic\s+interj\.\s*', # Gaelic interjection
    r'^Thai\s+n\.\s*',    # Thai noun
    r'^S\.\s*Africa\s+n\.\s*', # South African noun
    r'^NZ\s+n\.\s*',      # New Zealand noun
    r'^NZ\s+rhym\.\s*slang\s*', # NZ rhyming slang
    r'^US\s+abbr\.\s*',   # US abbreviation
    r'^US\s+adj\.\s*',    # US adjective
    r'^US\s*',            # Just US prefix
    r'^Aus\s*',           # Just Aus prefix
    r'^Eire\s*',          # Just Eire prefix
    r'^N\.\s*Ireland\s*', # Northern Ireland
    r'^used\s+by\s+females\s*', # gender specific
    r'^used\s+by\s+males\s*',
    r'^fem\.\s*',         # feminine
    r'^male\s*',          # male
    r'^onomatopoeia\s*',  # onomatopoeia
    r'^70s\s*',           # decade
    r'^Olde\s+Worlde\s*', # old world
    r'^Latin\s+phrase\s*', # Latin
    r'^EEC\s+n\.\s*',     # EEC noun
    r'^TV\s+baldy\s*',    # TV reference
    r'^Planet\s+Skaros\s+Dalek\s+term\s+for\s*', # Doctor Who reference
    r'^variously\s*',     # various meanings
    r'^homophobic\s*',    # content warning
    r'^Roger\s+Mellie\s*', # reference
    r'^naval\s+slang\s*', # naval slang
]

def clean_definition(definition):
    """Remove type markers from the beginning of a definition"""
    if not definition:
        return definition
    
    cleaned = definition.strip()
    
    # Apply all marker patterns (case insensitive)
    for pattern in TYPE_MARKERS:
        cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE)
    
    # Also clean up any remaining standalone markers at start
    # Handle combined patterns like "Aus. attr." or "attr. Barry Humphries"
    cleaned = re.sub(r'^(Aus\.|attr\.)\s*(Barry\s+Humphries\s*)?', '', cleaned, flags=re.IGNORECASE)
    
    # Clean up extra whitespace
    cleaned = cleaned.strip()
    
    # Capitalize first letter if it's lowercase
    if cleaned and cleaned[0].islower():
        cleaned = cleaned[0].upper() + cleaned[1:]
    
    return cleaned

def fix_all_words():
    """Fix all words in the database"""
    print("Fixing dictionary entries...")
    
    all_words = list(words_collection.find())
    print(f"Found {len(all_words)} words in database")
    
    fixed_count = 0
    
    for word in all_words:
        original_def = word.get('definition', '')
        cleaned_def = clean_definition(original_def)
        
        if cleaned_def != original_def:
            # Update the word
            words_collection.update_one(
                {"_id": word["_id"]},
                {"$set": {"definition": cleaned_def}}
            )
            fixed_count += 1
            if fixed_count <= 10:
                print(f"Fixed: '{word['word']}'")
                print(f"  Before: {original_def[:60]}...")
                print(f"  After:  {cleaned_def[:60]}...")
    
    print(f"\nFixed {fixed_count} entries")
    return fixed_count

def remove_duplicates():
    """Remove duplicate word entries, keeping the one with better definition"""
    print("\nRemoving duplicates...")
    
    # Find duplicates by word (case insensitive)
    pipeline = [
        {"$group": {
            "_id": {"$toLower": "$word"},
            "count": {"$sum": 1},
            "docs": {"$push": {"id": "$_id", "word": "$word", "definition": "$definition"}}
        }},
        {"$match": {"count": {"$gt": 1}}}
    ]
    
    duplicates = list(words_collection.aggregate(pipeline))
    removed_count = 0
    
    for dup in duplicates:
        docs = dup['docs']
        # Keep the one with the longest definition
        docs.sort(key=lambda x: len(x['definition']), reverse=True)
        
        # Remove all but the first (best) one
        for doc in docs[1:]:
            words_collection.delete_one({"_id": doc['id']})
            removed_count += 1
            print(f"Removed duplicate: '{doc['word']}'")
    
    print(f"\nRemoved {removed_count} duplicates")
    return removed_count

if __name__ == "__main__":
    print("="*60)
    print("Dictionary Cleanup Script")
    print("="*60)
    
    fixed = fix_all_words()
    removed = remove_duplicates()
    
    print("\n" + "="*60)
    print("Summary:")
    print(f"  Definitions cleaned: {fixed}")
    print(f"  Duplicates removed: {removed}")
    print("="*60)
