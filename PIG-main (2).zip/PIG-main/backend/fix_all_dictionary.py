#!/usr/bin/env python3
"""
Comprehensive Dictionary Fix Script
1. Fix compound words that were incorrectly split
2. Capitalize all word entries properly
3. Clean up definitions
"""

import re
from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()

# MongoDB connection
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
client = MongoClient(MONGO_URL)
db = client.word_of_day_db
words_collection = db.words

# Type markers pattern - these indicate where the actual definition starts
TYPE_MARKERS = r'(n\.|v\.|adj\.|euph\.|abbr\.|interj\.|rhym\.\s*slang|sim\.|attr\.|slang)'

def fix_compound_words():
    """Fix compound words that were incorrectly split"""
    print("Fixing compound words...")
    
    all_words = list(words_collection.find())
    fixed_count = 0
    
    for word_doc in all_words:
        definition = word_doc.get('definition', '')
        word = word_doc.get('word', '')
        
        # Skip entries that are just regional markers like "British slang"
        if re.match(r'^(British|Scottish|Irish|Welsh|Vulgar|Extremely vulgar)\s+slang', definition):
            # These are fine - the definition properly describes the term
            continue
        
        # Pattern: Definition starts with Capitalized word(s) followed by type marker
        # e.g., "Rubber sock n. Condom" or "The worm euph. See bash the bishop"
        match = re.match(r'^([A-Z][a-z]+(?:\s+[a-z]+(?:\s+[a-z]+)?(?:\s+[a-z]+)?(?:\s+[a-z]+)?)?)\s+' + TYPE_MARKERS + r'\s*(.*)$', definition, re.IGNORECASE)
        
        if match:
            missing_part = match.group(1).strip()
            type_marker = match.group(2)
            actual_definition = match.group(3).strip()
            
            # Build the correct compound word
            new_word = f"{word} {missing_part.lower()}"
            
            # Title case the word properly
            new_word_titled = ' '.join(w.capitalize() if i == 0 or w not in ['the', 'a', 'an', 'of', 'in', 'on', 'at', 'to', 'for', 'and', 'or', 'your', 'me'] 
                                       else w for i, w in enumerate(new_word.lower().split()))
            # Always capitalize first word
            words_list = new_word_titled.split()
            if words_list:
                words_list[0] = words_list[0].capitalize()
                new_word_titled = ' '.join(words_list)
            
            # Clean up the definition - remove the type marker
            if actual_definition:
                # Capitalize first letter of definition
                if actual_definition[0].islower():
                    actual_definition = actual_definition[0].upper() + actual_definition[1:]
            else:
                actual_definition = definition  # Keep original if no content after marker
            
            # Update the entry
            words_collection.update_one(
                {"_id": word_doc["_id"]},
                {"$set": {
                    "word": new_word_titled,
                    "definition": actual_definition
                }}
            )
            fixed_count += 1
            if fixed_count <= 30:
                print(f"  Fixed: '{word}' -> '{new_word_titled}'")
                print(f"    Def: {actual_definition[:60]}...")
    
    print(f"\nFixed {fixed_count} compound words")
    return fixed_count

def capitalize_all_words():
    """Ensure all word entries are properly capitalized"""
    print("\nCapitalizing word entries...")
    
    all_words = list(words_collection.find())
    fixed_count = 0
    
    for word_doc in all_words:
        word = word_doc.get('word', '')
        
        # Title case - capitalize first letter of each word, except common small words
        # But always capitalize the first word
        words_list = word.split()
        new_words = []
        for i, w in enumerate(words_list):
            if i == 0:
                # Always capitalize first word
                new_words.append(w.capitalize())
            elif w.lower() in ['the', 'a', 'an', 'of', 'in', 'on', 'at', 'to', 'for', 'and', 'or']:
                new_words.append(w.lower())
            elif w.isupper() and len(w) <= 3:
                # Keep acronyms uppercase (US, UK, etc.)
                new_words.append(w)
            else:
                new_words.append(w.capitalize())
        
        new_word = ' '.join(new_words)
        
        if new_word != word:
            words_collection.update_one(
                {"_id": word_doc["_id"]},
                {"$set": {"word": new_word}}
            )
            fixed_count += 1
            if fixed_count <= 20:
                print(f"  '{word}' -> '{new_word}'")
    
    print(f"\nCapitalized {fixed_count} words")
    return fixed_count

def clean_definitions():
    """Clean up any remaining issues in definitions"""
    print("\nCleaning definitions...")
    
    all_words = list(words_collection.find())
    fixed_count = 0
    
    for word_doc in all_words:
        definition = word_doc.get('definition', '')
        original = definition
        
        # Remove standalone type markers at the start
        definition = re.sub(r'^' + TYPE_MARKERS + r'\s*', '', definition)
        
        # Capitalize first letter if lowercase
        if definition and definition[0].islower():
            definition = definition[0].upper() + definition[1:]
        
        # Fix double spaces
        definition = re.sub(r'\s+', ' ', definition).strip()
        
        if definition != original:
            words_collection.update_one(
                {"_id": word_doc["_id"]},
                {"$set": {"definition": definition}}
            )
            fixed_count += 1
    
    print(f"Cleaned {fixed_count} definitions")
    return fixed_count

def remove_duplicates():
    """Remove duplicate entries"""
    print("\nRemoving duplicates...")
    
    pipeline = [
        {"$group": {
            "_id": {"$toLower": "$word"},
            "count": {"$sum": 1},
            "docs": {"$push": {"id": "$_id", "word": "$word", "definition": "$definition"}}
        }},
        {"$match": {"count": {"$gt": 1}}}
    ]
    
    duplicates = list(words_collection.aggregate(pipeline))
    removed_count = 0
    
    for dup in duplicates:
        docs = dup['docs']
        # Keep the one with the longest definition
        docs.sort(key=lambda x: len(x['definition']), reverse=True)
        
        for doc in docs[1:]:
            words_collection.delete_one({"_id": doc['id']})
            removed_count += 1
    
    print(f"Removed {removed_count} duplicates")
    return removed_count

if __name__ == "__main__":
    print("="*60)
    print("Comprehensive Dictionary Fix")
    print("="*60)
    
    compound_fixed = fix_compound_words()
    caps_fixed = capitalize_all_words()
    defs_cleaned = clean_definitions()
    dups_removed = remove_duplicates()
    
    final_count = words_collection.count_documents({})
    
    print("\n" + "="*60)
    print("Summary:")
    print(f"  Compound words fixed: {compound_fixed}")
    print(f"  Words capitalized: {caps_fixed}")
    print(f"  Definitions cleaned: {defs_cleaned}")
    print(f"  Duplicates removed: {dups_removed}")
    print(f"  Final word count: {final_count}")
    print("="*60)
