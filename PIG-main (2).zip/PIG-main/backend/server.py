from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from bson import ObjectId
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime, date
import random
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# MongoDB connection with retry logic for Atlas
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "word_of_day_db")

def get_mongo_client():
    """Create MongoDB client with Atlas-compatible settings"""
    return MongoClient(
        MONGO_URL,
        serverSelectionTimeoutMS=5000,
        connectTimeoutMS=10000,
        socketTimeoutMS=10000,
        retryWrites=True,
        w="majority"
    )

# Initialize client and database
client = get_mongo_client()
db = client[DB_NAME]
words_collection = db.words
daily_word_collection = db.daily_words

# Models
class Word(BaseModel):
    word: str
    definition: str
    is_favorite: bool = False

class WordUpdate(BaseModel):
    word: Optional[str] = None
    definition: Optional[str] = None
    is_favorite: Optional[bool] = None

class WordResponse(BaseModel):
    id: str
    word: str
    definition: str
    is_favorite: bool
    created_at: str

# Helper function to serialize MongoDB document
def serialize_word(word):
    return {
        "id": str(word["_id"]),
        "word": word["word"],
        "definition": word["definition"],
        "is_favorite": word.get("is_favorite", False),
        "created_at": word.get("created_at", datetime.utcnow().isoformat())
    }

# Initialize with sample words if database is empty
@app.on_event("startup")
async def startup_event():
    try:
        # Test connection first
        client.admin.command('ping')
        print("MongoDB connection successful")
        
        if words_collection.count_documents({}) == 0:
            sample_words = [
                {
                    "word": "Serendipity",
                    "definition": "The occurrence of events by chance in a happy or beneficial way. Finding something good without looking for it.",
                    "is_favorite": False,
                    "created_at": datetime.utcnow().isoformat()
                },
                {
                    "word": "Ephemeral",
                    "definition": "Lasting for a very short time. Something that exists briefly and then fades away or disappears.",
                    "is_favorite": False,
                    "created_at": datetime.utcnow().isoformat()
                },
                {
                    "word": "Luminous",
                    "definition": "Full of or shedding light; bright or shining. Can also mean very clear and easy to understand.",
                    "is_favorite": False,
                    "created_at": datetime.utcnow().isoformat()
                },
                {
                    "word": "Mellifluous",
                    "definition": "Sweet or musical; pleasant to hear. Often used to describe a smooth, rich sound or voice.",
                    "is_favorite": False,
                    "created_at": datetime.utcnow().isoformat()
                },
                {
                    "word": "Resilient",
                    "definition": "Able to withstand or recover quickly from difficult conditions. Having the ability to bounce back from adversity.",
                    "is_favorite": False,
                    "created_at": datetime.utcnow().isoformat()
                }
            ]
            words_collection.insert_many(sample_words)
            print("Initialized database with sample words")
    except Exception as e:
        print(f"Warning: Could not initialize database: {e}")

# Health check endpoint
@app.get("/health")
def health_check():
    try:
        client.admin.command('ping')
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Database connection failed: {str(e)}")

@app.get("/")
def read_root():
    return {"message": "Word of the Day API"}

# Get all words
@app.get("/api/words")
def get_words(limit: int = 100, skip: int = 0):
    words = list(words_collection.find({}, {"_id": 1, "word": 1, "definition": 1, "is_favorite": 1, "created_at": 1}).skip(skip).limit(limit))
    return [serialize_word(word) for word in words]

# Add new word
@app.post("/api/words")
def add_word(word: Word):
    word_dict = word.dict()
    word_dict["created_at"] = datetime.utcnow().isoformat()
    result = words_collection.insert_one(word_dict)
    word_dict["_id"] = result.inserted_id
    return serialize_word(word_dict)

# Update word
@app.put("/api/words/{word_id}")
def update_word(word_id: str, word: WordUpdate):
    try:
        object_id = ObjectId(word_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid word ID")
    
    update_data = {k: v for k, v in word.dict().items() if v is not None}
    
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")
    
    result = words_collection.update_one(
        {"_id": object_id},
        {"$set": update_data}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Word not found")
    
    updated_word = words_collection.find_one({"_id": object_id})
    return serialize_word(updated_word)

# Delete word
@app.delete("/api/words/{word_id}")
def delete_word(word_id: str):
    try:
        object_id = ObjectId(word_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid word ID")
    
    result = words_collection.delete_one({"_id": object_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Word not found")
    
    return {"message": "Word deleted successfully"}

# Toggle favorite status
@app.patch("/api/words/{word_id}/favorite")
def toggle_favorite(word_id: str):
    try:
        object_id = ObjectId(word_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid word ID")
    
    word = words_collection.find_one({"_id": object_id})
    
    if not word:
        raise HTTPException(status_code=404, detail="Word not found")
    
    new_favorite_status = not word.get("is_favorite", False)
    
    words_collection.update_one(
        {"_id": object_id},
        {"$set": {"is_favorite": new_favorite_status}}
    )
    
    updated_word = words_collection.find_one({"_id": object_id})
    return serialize_word(updated_word)

# Get word of the day
@app.get("/api/word-of-day")
def get_word_of_day():
    today = date.today().isoformat()
    
    # Check if we already have a word for today
    daily_word = daily_word_collection.find_one({"date": today})
    
    if daily_word:
        # Return the existing word for today
        word_id = daily_word["word_id"]
        word = words_collection.find_one({"_id": ObjectId(word_id)})
        if word:
            return serialize_word(word)
    
    # No word for today, select a random one using aggregation
    random_words = list(words_collection.aggregate([{"$sample": {"size": 1}}]))
    
    if not random_words:
        raise HTTPException(status_code=404, detail="No words in dictionary. Please add some words first.")
    
    random_word = random_words[0]
    
    # Save as today's word
    daily_word_collection.insert_one({
        "date": today,
        "word_id": str(random_word["_id"])
    })
    
    return serialize_word(random_word)

# Get favorite words
@app.get("/api/words/favorites")
def get_favorite_words():
    words = list(words_collection.find({"is_favorite": True}, {"_id": 1, "word": 1, "definition": 1, "is_favorite": 1, "created_at": 1}).limit(100))
    return [serialize_word(word) for word in words]

# Generate random insult using templates and dictionary words
@app.get("/api/generate-insult")
def generate_insult(
    intensity: Optional[str] = "medium",
    region: Optional[str] = "mixed",
    style: Optional[str] = "modern"
):
    # Modern British insult adjectives (no Shakespearean/Victorian)
    british_adjectives = [
        "absolute", "proper", "complete", "total", "utter", "massive", "right",
        "sodding", "bloody", "blimming", "blooming", "flaming", "ruddy", "bleeding",
        "daft", "dense", "dim", "thick", "dopey", "gormless", "clueless",
        "manky", "grotty", "minging", "rank", "naff", "pants", "rubbish",
        "barmy", "bonkers", "mental", "crackers", "nutty", "potty", "doolally",
        "cheeky", "gobby", "stroppy", "mardy", "narky", "ratty", "shirty",
        "jammy", "dodgy", "iffy", "sketchy", "suss", "bent", "wonky",
        "mingy", "tight", "stingy", "measly", "poxy", "tatty", "shabby"
    ]
    
    # Modern British insult nouns (actual slang, no archaic terms)
    british_nouns = [
        "muppet", "numpty", "wally", "plonker", "pillock", "prat", "twit",
        "berk", "git", "divvy", "donut", "melt", "melon", "weapon",
        "bellend", "knobhead", "dickhead", "tosser", "wanker", "twat",
        "minger", "scrubber", "slag", "slapper", "skank", "tramp",
        "knob", "nob", "tool", "spanner", "helmet", "rocket",
        "sausage", "nugget", "turnip", "cabbage", "carrot", "potato",
        "walloper", "whopper", "clown", "joker", "mug", "muggins",
        "plum", "prune", "lemon", "banana", "coconut", "watermelon",
        "nonce", "gimp", "drip", "wet", "flannel", "drongo",
        "nincompoop", "nitwit", "halfwit", "dimwit", "twonk", "womble"
    ]
    
    # Action verbs for creative insults
    action_verbs = [
        "boil", "fry", "pickle", "stuff", "shove", "stick", "ram",
        "chuck", "lob", "boot", "kick", "slap", "belt", "wallop"
    ]
    
    # Body parts / objects for creative constructions
    objects = [
        "head", "face", "arse", "backside", "ear", "elbow", "armpit",
        "teabag", "sausage roll", "kebab", "chippy", "bins", "wheelie bin"
    ]
    
    # Modern British insult templates (creative, no Shakespeare/Victorian)
    if intensity == "mild":
        templates = [
            "You're a bit of a {noun}, aren't you?",
            "Oi, you {noun}!",
            "Don't be such a {noun}!",
            "Stop being a {adj} {noun}!",
            "You're acting like a right {noun}!",
            "Pack it in, you {noun}!",
            "Alright {noun}, calm yourself!",
            "What are you playing at, you {noun}?",
            "You absolute {noun}!",
            "Behave yourself, you {noun}!"
        ]
    elif intensity == "savage":
        templates = [
            "You {adj} {noun}! I've met smarter {object}s!",
            "Absolute {adj} {noun} of a human being!",
            "You're thicker than a {noun} sandwich, you {adj} {noun2}!",
            "Listen here you {adj} {noun}, do one!",
            "Away and {verb} your {object}, you {adj} {noun}!",
            "You've got the brain of a {adj} {noun} and half the charm!",
            "You {adj} {noun}! Your mum should've swallowed!",
            "Shut your {adj} {object}, you complete {noun}!",
            "You couldn't organise a piss-up in a brewery, you {adj} {noun}!",
            "You're as useful as a chocolate teapot, you {adj} {noun}!",
            "Jog on you {adj} {noun}! Nobody asked!",
            "Wind your neck in you {adj} {noun}!",
            "You {adj}, {adj2} {noun} of a {noun2}!",
            "I've seen better looking {object}s than you, you {adj} {noun}!",
            "You're an absolute car crash of a {noun}, mate!"
        ]
    else:  # medium
        templates = [
            "You {adj} {noun}!",
            "You're a proper {adj} {noun}!",
            "What a {adj} {noun} you are!",
            "You absolute {adj} {noun}!",
            "Listen here you {adj} {noun}!",
            "You're nothing but a {adj} {noun}!",
            "You {adj} {noun} of a person!",
            "Oi, you {adj} {noun}!",
            "You're being a right {adj} {noun}!",
            "Away and {verb} yourself, you {noun}!",
            "You've got a face like a {adj} {object}!",
            "You're about as useful as a {adj} {noun}!",
            "What kind of {adj} {noun} does that?",
            "You {adj} little {noun}!",
            "Sort yourself out, you {adj} {noun}!"
        ]
    
    # Pick random template
    template = random.choice(templates)
    
    # Fill in template with random words
    adj1 = random.choice(british_adjectives)
    adj2 = random.choice([a for a in british_adjectives if a != adj1])
    noun1 = random.choice(british_nouns)
    noun2 = random.choice([n for n in british_nouns if n != noun1])
    verb = random.choice(action_verbs)
    obj = random.choice(objects)
    
    insult = template
    insult = insult.replace('{adj}', adj1)
    insult = insult.replace('{adj2}', adj2)
    insult = insult.replace('{noun}', noun1)
    insult = insult.replace('{noun2}', noun2)
    insult = insult.replace('{verb}', verb)
    insult = insult.replace('{object}', obj)
    
    # Capitalize first letter
    insult = insult[0].upper() + insult[1:]
    
    return {
        "insult": insult,
        "intensity": intensity,
        "region": region,
        "style": style
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)