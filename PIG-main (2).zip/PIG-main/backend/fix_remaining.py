#!/usr/bin/env python3
"""
Fix remaining compound word parsing issues
"""

import re
from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()

client = MongoClient(os.getenv("MONGO_URL", "mongodb://localhost:27017"))
db = client.word_of_day_db
words_collection = db.words

# Manual fixes for complex compound words
MANUAL_FIXES = [
    # (current_word, definition_pattern, new_word, new_definition)
    ("Bag", "Ladies' period", "Bag Ladies' Period", "Superlative of foul tasting."),
    ("Bannocks", "Scotch equivalent", "Bannocks", "Scotch equivalent of bollocks. Jockspeak for knackers; plums."),
    ("Build", "A log cabin", "Build a Log Cabin", "To pass an enormous, solid stool. As in: 'I wouldn't go in there mate. Someone's just built a log cabin'."),
    ("Bury", "A quaker", "Bury a Quaker", "To release a payload from the bomb bay."),
    ("Curl One Off", "curler n.", "Curl One Off", "To carefully deliver a stool. Curler: A lump of excrement so delivered. Also crimp off a length."),
    ("Grow", "A tail", "Grow a Tail", "To defecate; build a log cabin."),
    ("Heave", "A Havana", "Heave a Havana", "Take a dump. See also bum cigar."),
    ("Jizz", "Jism. v.", "Jizz", "Jism. To ejaculate."),
    ("Lake", "Wendouree", "Lake Wendouree", "Ejaculation, e.g. \"Oh my God... Uuughh! I'm in Lake Wendouree!\" From the lake at Ballarat Australia."),
    ("Lay", "A cable", "Lay a Cable", "Build a log cabin. See also cable laying."),
    ("Pinch", "A loaf", "Pinch a Loaf", "See curl one off."),
    ("Pirate", "Of men's pants", "Pirate of Men's Pants", "Swashbuckling term for your jolly Rogerer; cock; penis."),
    ("Pitch", "A tent", "Pitch a Tent", "To get wood beneath the bed linen, or conspicuously in ones trousers."),
    ("Playing", "The bone-a-phone", "Playing the Bone-a-phone", "Wanking; partaking of a hand shandy."),
    ("Pull", "A train", "Pull a Train", "To take turns at stirring the porridge; for a group of men to all have sex with the same lady friend."),
    ("Shave", "A horse", "Shave a Horse", "To have a piss; take a leak."),
    ("Spend", "Tuppence", "Spend Tuppence in Ha'pennies and Farthings", "To pass loose stools; have diarrhoea."),
    ("Split", "A kipper", "Split a Kipper", "To have sex. As in 'This lady appears to like me. With luck I may later have the opportunity to split a kipper'."),
    ("Take", "A Chinese", "Take a Chinese Singing Lesson", "Have a piss."),
    ("Throwing", "A Woodbine", "Throwing a Woodbine Down Northumberland Street", "Unsatisfying sex with a bucket fannied individual. As in: 'Why man, it was like throwin' a fuckin' Woodbine doon Northumberland Street'. Also Leeds: throwing a sausage up Briggate."),
]

def fix_manual_entries():
    """Apply manual fixes for complex compound words"""
    print("Applying manual fixes...")
    fixed = 0
    
    for current_word, def_pattern, new_word, new_definition in MANUAL_FIXES:
        result = words_collection.update_one(
            {"word": current_word, "definition": {"$regex": f"^{re.escape(def_pattern)}", "$options": "i"}},
            {"$set": {"word": new_word, "definition": new_definition}}
        )
        if result.modified_count:
            print(f"  Fixed: '{current_word}' -> '{new_word}'")
            fixed += 1
    
    return fixed

def fix_remaining_patterns():
    """Fix any remaining patterns with type markers in definitions"""
    print("\nFixing remaining patterns...")
    
    all_words = list(words_collection.find())
    fixed = 0
    
    for word_doc in all_words:
        definition = word_doc.get('definition', '')
        word = word_doc.get('word', '')
        original_def = definition
        
        # Pattern 1: "Word(s) euph. actual definition" or "Word(s) v. actual definition"
        match = re.match(r'^([A-Z][a-z\']+(?:\s+[a-z\']+)*)\s+(euph\.|v\.|n\.|sim\.|adj\.)\s*(.+)$', definition)
        if match:
            missing_part = match.group(1)
            actual_def = match.group(3)
            
            new_word = f"{word} {missing_part}".title()
            # Fix title case for small words
            new_word = re.sub(r'\b(A|An|The|Of|In|On|At|To|For|And|Or)\b', lambda m: m.group(1).lower(), new_word)
            # But capitalize first word
            new_word = new_word[0].upper() + new_word[1:]
            
            # Capitalize definition
            if actual_def and actual_def[0].islower():
                actual_def = actual_def[0].upper() + actual_def[1:]
            
            words_collection.update_one(
                {"_id": word_doc["_id"]},
                {"$set": {"word": new_word, "definition": actual_def}}
            )
            fixed += 1
            if fixed <= 20:
                print(f"  Fixed: '{word}' -> '{new_word}'")
    
    return fixed

def clean_definitions():
    """Remove any remaining standalone type markers from definitions"""
    print("\nCleaning definitions...")
    
    all_words = list(words_collection.find())
    fixed = 0
    
    for word_doc in all_words:
        definition = word_doc.get('definition', '')
        original = definition
        
        # Remove standalone type markers
        definition = re.sub(r'\s+(n\.|v\.|adj\.|euph\.)\s+', ' ', definition)
        definition = re.sub(r'^(n\.|v\.|adj\.|euph\.)\s+', '', definition)
        
        # Capitalize first letter
        if definition and definition[0].islower():
            definition = definition[0].upper() + definition[1:]
        
        if definition != original:
            words_collection.update_one(
                {"_id": word_doc["_id"]},
                {"$set": {"definition": definition}}
            )
            fixed += 1
    
    return fixed

if __name__ == "__main__":
    print("="*60)
    print("Fixing Remaining Parsing Issues")
    print("="*60)
    
    manual = fix_manual_entries()
    patterns = fix_remaining_patterns()
    cleaned = clean_definitions()
    
    print("\n" + "="*60)
    print(f"Manual fixes applied: {manual}")
    print(f"Pattern fixes: {patterns}")
    print(f"Definitions cleaned: {cleaned}")
    print("="*60)
