# Bulk Word Import - Usage Guide

## Overview
This script allows you to import hundreds of custom dictionary words at once into your Word of the Day app.

## Files Created
- **`bulk_import_words.py`** - The import script
- **`custom_dictionary.txt`** - Sample dictionary file (add your words here)

## Dictionary Format
Your dictionary file should follow this format:

```
word n. Definition goes here.

another word v. Another definition here.

third word adj. A third definition.
```

**Supported tags:** n. (noun), v. (verb), adj. (adjective), euph. (euphemism), abbr. (abbreviation), interj. (interjection), rhym. slang (rhyming slang), sim. (simile), US, Aus, UK, Scotch, Gaelic, etc.

## Usage

### Step 1: Add Your Words
Edit `custom_dictionary.txt` and paste all your dictionary entries in the format above.

### Step 2: Run the Import Script
```bash
cd /app/backend
python3 bulk_import_words.py custom_dictionary.txt
```

### Step 3: Review
The script will:
1. Parse all entries
2. Show a preview of the first 3 words
3. Ask for confirmation
4. Import all words with progress tracking
5. Show a summary with success/failure counts

## Example Run

```bash
$ python3 bulk_import_words.py custom_dictionary.txt

📖 Parsing dictionary entries...
✅ Parsed 500 words

Preview of first 3 words:
  • Air biscuit: Fart; botty burp. As in 'Has somebody launched an air biscuit?'...
  • Almond: 1. Penis. From the rhyming slang, almond rock cock. 2. An imperial mea...
  • Anal announcement: Fart; botty burp; trouser trumpet....

Import 500 words? (yes/no): yes

📚 Starting import of 500 words...

✓ [1/500] Added: Air biscuit
✓ [2/500] Added: Almond
✓ [3/500] Added: Anal announcement
...

============================================================
📊 Import Summary:
   ✅ Successfully imported: 497
   ❌ Failed: 3
   📈 Success rate: 99.4%
============================================================
```

## Tips
- The script handles special characters automatically
- It adds a small delay between batches to avoid overwhelming the API
- Failed imports are tracked and reported at the end
- You can run the script multiple times (duplicates will fail gracefully)

## Troubleshooting

**Problem:** "No words found in the file"
- Check that entries follow the format: `word n. Definition.`
- Ensure there's a space after the word and before the part of speech

**Problem:** Import fails
- Make sure the backend is running: `sudo supervisorctl status backend`
- Check the backend is accessible: `curl http://localhost:8001/api/words`

**Problem:** Some words fail to import
- Check the error message in the output
- Verify the word doesn't already exist
- Ensure definition isn't empty

## Next Steps
After import, your words will be:
- Visible in the Dictionary screen
- Available for Word of the Day selection
- Searchable and editable through the app
