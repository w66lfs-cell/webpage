import { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Hero from './components/Hero'
import InsultGenerator from './components/InsultGenerator'
import WordOfDay from './components/WordOfDay'
import Dictionary from './components/Dictionary'
import Footer from './components/Footer'

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || ''

function App() {
  return (
    <BrowserRouter>
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
        <Header />
        <main style={{ flex: 1 }}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/dictionary" element={<Dictionary backendUrl={BACKEND_URL} />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  )
}

function HomePage() {
  return (
    <>
      <Hero />
      <InsultGenerator backendUrl={BACKEND_URL} />
      <WordOfDay backendUrl={BACKEND_URL} />
    </>
  )
}

export default App
