export default function Footer() {
  return (
    <footer style={styles.footer}>
      <div style={styles.container}>
        <div style={styles.logo}>
          <span style={styles.pigEmoji}>🐷</span>
          <span style={styles.logoText}>P.I.G</span>
        </div>
        <p style={styles.tagline}>Personal Insult Generator - British Insults Since 2024</p>
        <p style={styles.copyright}>© {new Date().getFullYear()} P.I.G. All rights reserved.</p>
      </div>
    </footer>
  )
}

const styles: Record<string, React.CSSProperties> = {
  footer: {
    background: '#0f172a',
    borderTop: '1px solid rgba(148,163,184,0.1)',
    padding: '40px 24px',
    textAlign: 'center',
  },
  container: {
    maxWidth: 800,
    margin: '0 auto',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 12,
  },
  pigEmoji: {
    fontSize: 28,
  },
  logoText: {
    fontSize: 20,
    fontWeight: 800,
    color: '#f8fafc',
    letterSpacing: 2,
  },
  tagline: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 8,
  },
  copyright: {
    fontSize: 12,
    color: '#475569',
  },
}
