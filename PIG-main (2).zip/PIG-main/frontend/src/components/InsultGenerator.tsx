import { useState } from 'react'
import { Flame, Copy, RefreshCw, Share2 } from 'lucide-react'

interface Props {
  backendUrl: string
}

export default function InsultGenerator({ backendUrl }: Props) {
  const [insult, setInsult] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)

  const generateInsult = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${backendUrl}/api/generate-insult`)
      const data = await response.json()
      setInsult(data.insult)
    } catch (error) {
      console.error('Error generating insult:', error)
      setInsult("You absolute muppet!")
    } finally {
      setLoading(false)
    }
  }

  const copyToClipboard = () => {
    if (insult) {
      navigator.clipboard.writeText(insult)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const shareInsult = () => {
    if (insult && navigator.share) {
      navigator.share({
        title: 'P.I.G - British Insult',
        text: insult,
      })
    }
  }

  return (
    <section style={styles.section} id="generator">
      <div style={styles.container}>
        <div style={styles.header}>
          <Flame size={32} color="#ef4444" />
          <h2 style={styles.title}>Insult Generator</h2>
        </div>
        <p style={styles.subtitle}>
          Generate a random British insult with proper flair
        </p>

        <div style={styles.card}>
          {insult ? (
            <div style={styles.insultContainer}>
              <p style={styles.insult}>"{insult}"</p>
              <div style={styles.actions}>
                <button style={styles.actionButton} onClick={copyToClipboard}>
                  <Copy size={18} />
                  {copied ? 'Copied!' : 'Copy'}
                </button>
                <button style={styles.actionButton} onClick={shareInsult}>
                  <Share2 size={18} />
                  Share
                </button>
              </div>
            </div>
          ) : (
            <p style={styles.placeholder}>
              Click the button below to generate your first insult!
            </p>
          )}

          <button 
            style={{
              ...styles.generateButton,
              opacity: loading ? 0.7 : 1,
            }}
            onClick={generateInsult}
            disabled={loading}
          >
            <RefreshCw size={20} style={{ animation: loading ? 'spin 1s linear infinite' : 'none' }} />
            {loading ? 'Generating...' : 'Generate Insult'}
          </button>
        </div>
      </div>
    </section>
  )
}

const styles: Record<string, React.CSSProperties> = {
  section: {
    padding: '80px 24px',
    background: '#0f172a',
  },
  container: {
    maxWidth: 700,
    margin: '0 auto',
    textAlign: 'center',
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 12,
  },
  title: {
    fontSize: 36,
    fontWeight: 800,
    color: '#f8fafc',
  },
  subtitle: {
    fontSize: 16,
    color: '#94a3b8',
    marginBottom: 32,
  },
  card: {
    background: 'linear-gradient(135deg, #1e293b 0%, #334155 100%)',
    borderRadius: 24,
    padding: 40,
    border: '1px solid rgba(148,163,184,0.1)',
    boxShadow: '0 20px 40px rgba(0,0,0,0.3)',
  },
  insultContainer: {
    marginBottom: 32,
  },
  insult: {
    fontSize: 28,
    fontWeight: 600,
    color: '#f8fafc',
    lineHeight: 1.5,
    marginBottom: 24,
    fontStyle: 'italic',
  },
  placeholder: {
    fontSize: 18,
    color: '#64748b',
    marginBottom: 32,
  },
  actions: {
    display: 'flex',
    justifyContent: 'center',
    gap: 12,
  },
  actionButton: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    padding: '10px 20px',
    borderRadius: 12,
    background: 'rgba(148,163,184,0.1)',
    color: '#94a3b8',
    fontSize: 14,
    fontWeight: 500,
    transition: 'all 0.2s ease',
  },
  generateButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    width: '100%',
    padding: '16px 32px',
    borderRadius: 16,
    background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
    color: '#fff',
    fontSize: 18,
    fontWeight: 700,
    transition: 'all 0.2s ease',
    boxShadow: '0 8px 20px rgba(239,68,68,0.3)',
  },
}
