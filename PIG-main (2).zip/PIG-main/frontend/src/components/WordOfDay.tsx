import { useState, useEffect } from 'react'
import { RefreshCw } from 'lucide-react'

interface Props {
  backendUrl: string
}

interface Word {
  id: string
  word: string
  definition: string
}

export default function WordOfDay({ backendUrl }: Props) {
  const [word, setWord] = useState<Word | null>(null)
  const [loading, setLoading] = useState(true)

  const fetchWordOfDay = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${backendUrl}/api/word-of-day`)
      const data = await response.json()
      setWord(data)
    } catch (error) {
      console.error('Error fetching word of day:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchWordOfDay()
  }, [backendUrl])

  return (
    <section style={styles.section}>
      <div style={styles.container}>
        <div style={styles.header}>
          <span style={styles.pigEmoji}>🐷</span>
          <h2 style={styles.title}>Word of the Day</h2>
        </div>
        <p style={styles.subtitle}>Expand your vocabulary with a new insult each day</p>

        <div style={styles.card}>
          {loading ? (
            <div style={styles.loading}>
              <RefreshCw size={32} color="#8b5cf6" style={{ animation: 'spin 1s linear infinite' }} />
              <p>Loading today's word...</p>
            </div>
          ) : word ? (
            <>
              <h3 style={styles.word}>{word.word}</h3>
              <p style={styles.definition}>{word.definition}</p>
            </>
          ) : (
            <p style={styles.error}>Could not load word of the day</p>
          )}
        </div>
      </div>
    </section>
  )
}

const styles: Record<string, React.CSSProperties> = {
  section: {
    padding: '80px 24px',
    background: 'linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%)',
  },
  container: {
    maxWidth: 700,
    margin: '0 auto',
    textAlign: 'center',
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 12,
  },
  pigEmoji: {
    fontSize: 32,
  },
  title: {
    fontSize: 36,
    fontWeight: 800,
    color: '#f8fafc',
  },
  subtitle: {
    fontSize: 16,
    color: '#94a3b8',
    marginBottom: 32,
  },
  card: {
    background: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
    borderRadius: 24,
    padding: 48,
    boxShadow: '0 20px 40px rgba(139,92,246,0.3)',
  },
  loading: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 16,
    color: '#fff',
  },
  word: {
    fontSize: 42,
    fontWeight: 800,
    color: '#fff',
    marginBottom: 16,
    textShadow: '0 2px 10px rgba(0,0,0,0.2)',
  },
  definition: {
    fontSize: 20,
    color: 'rgba(255,255,255,0.9)',
    lineHeight: 1.6,
  },
  error: {
    fontSize: 18,
    color: 'rgba(255,255,255,0.7)',
  },
}
