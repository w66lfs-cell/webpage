export default function Hero() {
  return (
    <section style={styles.hero}>
      <div style={styles.container}>
        <div style={styles.pigContainer}>
          <span style={styles.pigEmoji}>🐷</span>
        </div>
        <h1 style={styles.title}>P.I.G</h1>
        <p style={styles.subtitle}>Personal Insult Generator</p>
        <p style={styles.description}>
          Your one-stop shop for authentic British insults. 
          Over 950 carefully curated terms to help you express your displeasure 
          with proper British flair.
        </p>
        <div style={styles.stats}>
          <div style={styles.stat}>
            <span style={styles.statNumber}>953</span>
            <span style={styles.statLabel}>British Insults</span>
          </div>
          <div style={styles.stat}>
            <span style={styles.statNumber}>100%</span>
            <span style={styles.statLabel}>Authentic</span>
          </div>
          <div style={styles.stat}>
            <span style={styles.statNumber}>Free</span>
            <span style={styles.statLabel}>Forever</span>
          </div>
        </div>
      </div>
    </section>
  )
}

const styles: Record<string, React.CSSProperties> = {
  hero: {
    background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 50%, #1e1b4b 100%)',
    padding: '80px 24px',
    textAlign: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  container: {
    maxWidth: 800,
    margin: '0 auto',
  },
  pigContainer: {
    marginBottom: 24,
  },
  pigEmoji: {
    fontSize: 80,
    display: 'inline-block',
    animation: 'pulse 2s ease-in-out infinite',
  },
  title: {
    fontSize: 72,
    fontWeight: 900,
    color: '#f8fafc',
    letterSpacing: 4,
    marginBottom: 8,
    textShadow: '0 4px 20px rgba(236,72,153,0.3)',
  },
  subtitle: {
    fontSize: 20,
    color: '#ec4899',
    fontWeight: 600,
    marginBottom: 24,
    letterSpacing: 2,
    textTransform: 'uppercase',
  },
  description: {
    fontSize: 18,
    color: '#94a3b8',
    lineHeight: 1.7,
    maxWidth: 600,
    margin: '0 auto 40px',
  },
  stats: {
    display: 'flex',
    justifyContent: 'center',
    gap: 48,
    flexWrap: 'wrap',
  },
  stat: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 36,
    fontWeight: 800,
    color: '#f8fafc',
  },
  statLabel: {
    fontSize: 14,
    color: '#64748b',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
}
