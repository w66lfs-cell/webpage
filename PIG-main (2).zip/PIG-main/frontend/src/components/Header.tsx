import { Link } from 'react-router-dom'
import { Flame, Book } from 'lucide-react'

export default function Header() {
  return (
    <header style={styles.header}>
      <div style={styles.container}>
        <Link to="/" style={styles.logo}>
          <span style={styles.pigEmoji}>🐷</span>
          <span style={styles.logoText}>P.I.G</span>
        </Link>
        <nav style={styles.nav}>
          <Link to="/" style={styles.navLink}>
            <Flame size={18} />
            Generator
          </Link>
          <Link to="/dictionary" style={styles.navLink}>
            <Book size={18} />
            Dictionary
          </Link>
        </nav>
      </div>
    </header>
  )
}

const styles: Record<string, React.CSSProperties> = {
  header: {
    background: 'linear-gradient(180deg, rgba(15,23,42,0.98) 0%, rgba(15,23,42,0.9) 100%)',
    backdropFilter: 'blur(10px)',
    borderBottom: '1px solid rgba(148,163,184,0.1)',
    position: 'sticky',
    top: 0,
    zIndex: 100,
  },
  container: {
    maxWidth: 1200,
    margin: '0 auto',
    padding: '16px 24px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    textDecoration: 'none',
  },
  pigEmoji: {
    fontSize: 32,
  },
  logoText: {
    fontSize: 24,
    fontWeight: 800,
    color: '#f8fafc',
    letterSpacing: 2,
  },
  nav: {
    display: 'flex',
    gap: 8,
  },
  navLink: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    padding: '10px 20px',
    borderRadius: 12,
    background: 'rgba(148,163,184,0.1)',
    color: '#94a3b8',
    fontSize: 14,
    fontWeight: 500,
    transition: 'all 0.2s ease',
  },
}
