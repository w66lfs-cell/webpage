import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Search, ArrowLeft, Book } from 'lucide-react'

interface Props {
  backendUrl: string
}

interface Word {
  id: string
  word: string
  definition: string
}

export default function Dictionary({ backendUrl }: Props) {
  const [words, setWords] = useState<Word[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(0)
  const limit = 50

  const fetchWords = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${backendUrl}/api/words?limit=${limit}&skip=${page * limit}`)
      const data = await response.json()
      setWords(data)
    } catch (error) {
      console.error('Error fetching words:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchWords()
  }, [backendUrl, page])

  const filteredWords = words.filter(
    (word) =>
      word.word.toLowerCase().includes(search.toLowerCase()) ||
      word.definition.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <Link to="/" style={styles.backLink}>
          <ArrowLeft size={20} />
          Back to Home
        </Link>

        <div style={styles.header}>
          <Book size={40} color="#8b5cf6" />
          <h1 style={styles.title}>British Insult Dictionary</h1>
          <p style={styles.subtitle}>953 carefully curated terms for the discerning linguist</p>
        </div>

        <div style={styles.searchContainer}>
          <Search size={20} color="#64748b" style={styles.searchIcon} />
          <input
            type="text"
            placeholder="Search words or definitions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={styles.searchInput}
          />
        </div>

        {loading ? (
          <div style={styles.loading}>Loading dictionary...</div>
        ) : (
          <>
            <div style={styles.wordList}>
              {filteredWords.map((word) => (
                <div key={word.id} style={styles.wordCard}>
                  <h3 style={styles.wordTitle}>{word.word}</h3>
                  <p style={styles.wordDefinition}>{word.definition}</p>
                </div>
              ))}
            </div>

            <div style={styles.pagination}>
              <button
                style={{ ...styles.pageButton, opacity: page === 0 ? 0.5 : 1 }}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
              >
                Previous
              </button>
              <span style={styles.pageInfo}>Page {page + 1}</span>
              <button
                style={{ ...styles.pageButton, opacity: words.length < limit ? 0.5 : 1 }}
                onClick={() => setPage((p) => p + 1)}
                disabled={words.length < limit}
              >
                Next
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    background: '#0f172a',
    padding: '40px 24px',
  },
  container: {
    maxWidth: 900,
    margin: '0 auto',
  },
  backLink: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 8,
    color: '#94a3b8',
    fontSize: 14,
    marginBottom: 32,
    textDecoration: 'none',
  },
  header: {
    textAlign: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 42,
    fontWeight: 800,
    color: '#f8fafc',
    marginTop: 16,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#94a3b8',
  },
  searchContainer: {
    position: 'relative',
    marginBottom: 32,
  },
  searchIcon: {
    position: 'absolute',
    left: 16,
    top: '50%',
    transform: 'translateY(-50%)',
  },
  searchInput: {
    width: '100%',
    padding: '16px 16px 16px 48px',
    borderRadius: 16,
    border: '1px solid rgba(148,163,184,0.2)',
    background: '#1e293b',
    color: '#f8fafc',
    fontSize: 16,
    outline: 'none',
  },
  loading: {
    textAlign: 'center',
    color: '#94a3b8',
    fontSize: 18,
    padding: 40,
  },
  wordList: {
    display: 'grid',
    gap: 16,
  },
  wordCard: {
    background: '#1e293b',
    borderRadius: 16,
    padding: 24,
    border: '1px solid rgba(148,163,184,0.1)',
    transition: 'all 0.2s ease',
  },
  wordTitle: {
    fontSize: 20,
    fontWeight: 700,
    color: '#f8fafc',
    marginBottom: 8,
  },
  wordDefinition: {
    fontSize: 15,
    color: '#94a3b8',
    lineHeight: 1.6,
  },
  pagination: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 24,
    marginTop: 40,
  },
  pageButton: {
    padding: '12px 24px',
    borderRadius: 12,
    background: '#334155',
    color: '#f8fafc',
    fontSize: 14,
    fontWeight: 600,
  },
  pageInfo: {
    color: '#94a3b8',
    fontSize: 14,
  },
}
